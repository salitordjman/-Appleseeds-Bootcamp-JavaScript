1. Create The HTML

2. Create the CSS

3. Create The World

   # Create a matrix with different numbers that will correspond to the different elements on the screen

   # loop over my matrix, on each loop ill create a div and assign a different class depending on the number.

4. Create an Object the will hold my games state

   # my different tools

- inside my tools name of tool, image of tool, and what element it can remove
  -- axe > trees
  -- pickAxe > rocks
  -- shovel > dirt

# materialTypes I have for the world

- sky,leafs,trunk, rock, dirt

# an empty array to store my materials mined

# current material I have mined from the world

# current tool i choose from my inventory

## remove from the world = true or false

4.  Populate my html

# Put all my tool kits in the tool-bar div

Logic of the game

1. attach event listener click to all matrix elements

# call a function if I want to remove element from world

# call a function if I want to add element to the world

(now I understood I need to have a state if I should remove from the world or not so I add it to my state object pseudo code)

2. Attach event listener to tools

# change current tool to the tool you clicked on

3.  Remove Element from the world

# find out what element you need to remove

# style current tool in a border color
